<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcart}prestashop>blockcart_c2e1362a9710a3dd86f937c2ea1f336d'] = 'Корзина покупателя';
$_MODULE['<{blockcart}prestashop>blockcart_e03093a5753b436ee1de63b6e3e1bd02'] = 'Добавляет блок, содержащий корзину покупателя.';
$_MODULE['<{blockcart}prestashop>blockcart_a21e5718d2a196280b729438933501c7'] = 'Ajax: неверный выбор.';
$_MODULE['<{blockcart}prestashop>blockcart_02c793e3df4632db20e4d6e146095d62'] = 'Пожалуйста, заполните поле "Показывать товаров".';
$_MODULE['<{blockcart}prestashop>blockcart_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{blockcart}prestashop>blockcart_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockcart}prestashop>blockcart_614a8820aa4ac08ce2ee398a41b10778'] = 'Ajax-корзина';
$_MODULE['<{blockcart}prestashop>blockcart_eefd19ecf1f6d94a308dcfc95981bbf9'] = 'Активация Ajax-режима корзины (совместимо со стандартной темой).';
$_MODULE['<{blockcart}prestashop>blockcart_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockcart}prestashop>blockcart_b9f5c797ebbf55adccdd8539a65a0241'] = 'Отключено';
$_MODULE['<{blockcart}prestashop>blockcart_ce8bd2479bb85218eb304a9a2903a157'] = 'Показывать товаров  в блоке перекрестной продажи';
$_MODULE['<{blockcart}prestashop>blockcart_5f2effb52d25d197793288dfa94c27ce'] = 'Задайте число товаров для вывода в блоке перекрестной продажи.';
$_MODULE['<{blockcart}prestashop>blockcart_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockcart}prestashop>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Модификация №';
$_MODULE['<{blockcart}prestashop>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'удалить товар из корзины';
$_MODULE['<{blockcart}prestashop>blockcart_c6995d6cc084c192bc2e742f052a5c74'] = 'Бесплатная доставка!';
$_MODULE['<{blockcart}prestashop>blockcart_e7a6ca4e744870d455a57b644f696457'] = 'Бесплатно!';
$_MODULE['<{blockcart}prestashop>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Удалить';
$_MODULE['<{blockcart}prestashop>blockcart_0c3bf3014aafb90201805e45b5e62881'] = 'Просмотр корзины';
$_MODULE['<{blockcart}prestashop>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Корзина';
$_MODULE['<{blockcart}prestashop>blockcart_068f80c7519d0528fb08e82137a72131'] = 'товара(ов)';
$_MODULE['<{blockcart}prestashop>blockcart_deb10517653c255364175796ace3553f'] = 'товар';
$_MODULE['<{blockcart}prestashop>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(пусто)';
$_MODULE['<{blockcart}prestashop>blockcart_0da4d96cad73748e2f608d31cfb3247c'] = 'Удалить этот товар из корзины.';
$_MODULE['<{blockcart}prestashop>blockcart_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Подробно о товаре';
$_MODULE['<{blockcart}prestashop>blockcart_3d9e3bae9905a12dae384918ed117a26'] = 'Модификация №%d:';
$_MODULE['<{blockcart}prestashop>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Нет товаров';
$_MODULE['<{blockcart}prestashop>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Доставка:';
$_MODULE['<{blockcart}prestashop>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Упаковка';
$_MODULE['<{blockcart}prestashop>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'НДС';
$_MODULE['<{blockcart}prestashop>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Итого, к оплате:';
$_MODULE['<{blockcart}prestashop>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'Цены указаны с учетом НДС';
$_MODULE['<{blockcart}prestashop>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'Цены указаны без учёта НДС';
$_MODULE['<{blockcart}prestashop>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Оформить заказ';
$_MODULE['<{blockcart}prestashop>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'Покупатели этого товара так же приобрели:';
$_MODULE['<{blockcart}prestashop>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'Назад';
$_MODULE['<{blockcart}prestashop>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'См.';
$_MODULE['<{blockcart}prestashop>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Далее';
$_MODULE['<{blockcart}prestashop>blockcart_98b3009e61879600839e1ee486bb3282'] = 'Закрыть окно';
$_MODULE['<{blockcart}prestashop>blockcart_544c3bd0eac526113a9c66542be1e5bc'] = 'Товар добавлен в корзину';
$_MODULE['<{blockcart}prestashop>blockcart_694e8d1f2ee056f98ee488bdc4982d73'] = 'Количество';
$_MODULE['<{blockcart}prestashop>blockcart_e5694b7726ceaf2f057e5f06cf86209e'] = 'Товаров в корзине: [1]%d[/1].';
$_MODULE['<{blockcart}prestashop>blockcart_fc86c43dbffcadc193832a310f7a444a'] = 'Сейчас в корзине 1 товар.';
$_MODULE['<{blockcart}prestashop>blockcart_db205f01b4fd580fb5daa9072d96849d'] = 'Стоимость:';
$_MODULE['<{blockcart}prestashop>blockcart_21034ae6d01a83e702839a72ba8a77b0'] = '(без НДС)';
$_MODULE['<{blockcart}prestashop>blockcart_1f87346a16cf80c372065de3c54c86d9'] = '(вкл. НДС)';
$_MODULE['<{blockcart}prestashop>blockcart_f4e8b53a114e5a17d051ab84d326cae5'] = 'Стоимость доставки';
$_MODULE['<{blockcart}prestashop>blockcart_300225ee958b6350abc51805dab83c24'] = 'Продолжить покупки';
$_MODULE['<{blockcart}prestashop>blockcart_7e0bf6d67701868aac3116ade8fea957'] = 'Оформить заказ';


return $_MODULE;
