<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_736e9c57680cf9d22827202d562899ae'] = 'Button für soziale Netzwerke  Smart Blog';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_70bce4e1c0f15e09b66f0c2e58b97c65'] = 'Es ist das funktionellste Modul des Blogs mit dem Button für soziale Netzwerke für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
