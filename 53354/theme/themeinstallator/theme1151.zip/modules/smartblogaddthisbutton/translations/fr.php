<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_736e9c57680cf9d22827202d562899ae'] = 'Module Smart Blog Bouton Ajouter Ceci';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_70bce4e1c0f15e09b66f0c2e58b97c65'] = 'Le Plus Puissant Module de Bouton Ajouter Ceci pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogaddthisbutton}prestashop>smartblogaddthisbutton_fa214007826415a21a8456e3e09f999d'] = 'Êtes-vous sûr de vouloir supprimer vos informations ?';
