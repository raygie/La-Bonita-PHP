<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_d37e8c024f72eac2a69064e3263e340b'] = 'Búsqueda de Smart Blog';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_f40a8cf9474d456f08a0af54ac5d47ae'] = 'El Más Poderoso Módulo de Búsqueda para Blogs de Presta shop – por smartdatasoft';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_496d09a4b58f276873f653cbd25f8ced'] = 'Búsqueda de blog';
$_MODULE['<{smartblogsearch}prestashop>smartblogsearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
