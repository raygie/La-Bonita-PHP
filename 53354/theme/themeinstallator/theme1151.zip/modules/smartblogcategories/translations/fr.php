<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogcategories}prestashop>smartblogcategories_33158a2987fa386a6966e98bc25d2790'] = 'Smart Blog Catégories';
$_MODULE['<{smartblogcategories}prestashop>smartblogcategories_a14895030612094493056c982a7089c9'] = 'Le Plus Puissant Module de Tag pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogcategories}prestashop>smartblogcategories_fa214007826415a21a8456e3e09f999d'] = 'Êtes-vous sûr de vouloir supprimer vos informations ?';
$_MODULE['<{smartblogcategories}prestashop>smartblogcategories_979ac0eb39f23e70f45b79282ccab548'] = 'Catégories de Blog';
