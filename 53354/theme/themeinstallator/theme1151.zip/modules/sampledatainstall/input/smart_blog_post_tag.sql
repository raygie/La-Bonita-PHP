DROP TABLE IF EXISTS `ps_smart_blog_post_tag`;
CREATE TABLE `ps_smart_blog_post_tag` (
  `id_tag` int(11) NOT NULL,
  `id_post` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/* Scheme for table ps_smart_blog_post_tag */
INSERT INTO `ps_smart_blog_post_tag` VALUES
('1','4'),
('2','4'),
('3','4'),
('4','4'),
('5','4'),
('6','4'),
('7','4'),
('8','4'),
('9','4'),
('10','4'),
('11','4'),
('12','4'),
('13','4'),
('14','4'),
('15','4');
