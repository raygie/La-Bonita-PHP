<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_e2ed99e7e70947fd0b6e8f11ad2e086b'] = 'Smart Blog Aricles Liés';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_00ce49ece69e4185826980f107393bb8'] = 'Le Plus Puissant Module d\'Articles Liés pour Blog de shopping Presta Shop - par smartdatasoft';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_fa214007826415a21a8456e3e09f999d'] = 'Êtes-vous sûr de vouloir supprimer vos informations ?';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_21ee0d457c804ed84627ec8345f3c357'] = 'Les paramètres ont été mis à jour avec succès.';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_c54f9f209ed8fb4683e723daa4955377'] = 'Paramètres Généraux';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_9dfdf644519b32509c49e72a530e23c1'] = 'Afficher le Nombre d\'Articles Liés';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{smartblogrelatedposts}prestashop>smartblogrelatedposts_e84688fd88418fd094e3df7e39963631'] = 'Articles Liés:';
