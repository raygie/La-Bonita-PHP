<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d52ca18a939b1acb2f32144a746aa31a'] = 'Google карта ТМ';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_859f1a71b791416389b5fb30e3add3d6'] = 'Модуль для отображения ваших магазинов на Google карте.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_0828f9482bab5f7ec09c6abe4b57b411'] = 'Настройки Google карты';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d0ca6b472cdd35ae698c37b4ce35f036'] = 'Стили карты';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_ad0758b3464113f3af88cbc4c81bd527'] = 'Тип карты';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_29afbc227d97b08a97ca3c7bc254c409'] = 'Дорожная карта';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c2b5e73361a4bf9d26a73413d0abee5e'] = 'Спутник';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_920fa84052b3ce64dc1f65ea3f1c5f26'] = 'Уровень масштабирования';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_55789a5bd1237991256eca0233c15476'] = 'Укажите начальный уровень масштабирования карты (от 1 до 17)';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_5e3fb3b44c0709a7435a54b1918be739'] = 'Масштабирование при скролле';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_93cba07454f06a4a960172bbd6e2a435'] = 'Да';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Нет';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_d57241971d0c3c36b89995e232af0ed0'] = 'Включить масштабирование карты при прокрутке колесика мыши.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_fe7d8b0235665ec6199cf29afa9c44f6'] = 'Элементы управления картой';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_9cd21ce50f57ef8aefdf72b9d6d49512'] = 'Активировать элементы управления интерфейсом карты.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_b370d9ce079645ba296a91fdb639a529'] = 'Вид на улицу';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_46dd0ff51b2eb0b4fdd87a1b03af96e1'] = 'Включить параметр просмотра улицы.';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_630f6dc397fe74e52d5189e2c80f282b'] = 'Вернуться к списку';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_673ae02fffb72f0fe68a66f096a01347'] = 'Номер телефона';
$_MODULE['<{tmgooglemap}prestashop>tmgooglemap_a9407a9201ef1b64f0c567ed291574ba'] = 'Проложить маршрут';
