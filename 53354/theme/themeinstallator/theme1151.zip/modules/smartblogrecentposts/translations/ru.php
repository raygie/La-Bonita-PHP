<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_ae7bbe3f4039ab6bac9477cff467bee9'] = 'Свежие записи Smart Blog';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_a14895030612094493056c982a7089c9'] = 'Наиболее функциональный модуль блога с блоком свежих записей для Prestashop - от smartdatasoft';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_fa214007826415a21a8456e3e09f999d'] = 'Вы точно хотите удалить свои детали?';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_21ee0d457c804ed84627ec8345f3c357'] = 'Настройки успешно сохранены.';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c54f9f209ed8fb4683e723daa4955377'] = 'Основные параметры';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_d13ccfd7bbff943d14da1ec7e75a9e73'] = 'Количество свежих записей';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_58009509dfadf30a0c307129b13137d2'] = 'Свежие статьи';
