<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_ae7bbe3f4039ab6bac9477cff467bee9'] = 'Publicaciones Recientes de Smart Blog';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_a14895030612094493056c982a7089c9'] = 'Etiquetas del Más Poderoso Módulo de Blogs de Presta shop – por smartdatasoft';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_fa214007826415a21a8456e3e09f999d'] = '¿Estás seguro de querer borrar tus datos?';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_21ee0d457c804ed84627ec8345f3c357'] = 'La configuración ha sido actualizada con éxito.';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c54f9f209ed8fb4683e723daa4955377'] = 'Configuración General';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_d13ccfd7bbff943d14da1ec7e75a9e73'] = 'Mostrar el Número de Publicaciones Recientes';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{smartblogrecentposts}prestashop>smartblogrecentposts_58009509dfadf30a0c307129b13137d2'] = 'Artículos Recientes';
