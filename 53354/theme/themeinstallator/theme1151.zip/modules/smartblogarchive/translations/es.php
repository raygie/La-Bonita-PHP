<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_da1573901cef12a84b936db2e4a45142'] = 'Archivo de Smart Blog';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_9e5d3342fda20f4bdbe8009c8b10fb49'] = 'El Más Poderoso Módulo de Archivo de Blogs de Presta shop – por smartdatasoft';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_fa214007826415a21a8456e3e09f999d'] = '¿Estás seguro de querer borrar tus datos?';
$_MODULE['<{smartblogarchive}prestashop>smartblogarchive_ca18b5fea5dcf5c45e7af343d97e774c'] = 'Archivo del Blog';
