<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_dedc80ce5c0e352401b46ca83f4886c6'] = 'Populäre Posts Smart Blog';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_ade57742867203e98e1635d4ee17299e'] = 'Es ist das funktionellste Modul des Blogs mit dem Block der populären Posts für Prestashop - von smartdatasoft';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_fa214007826415a21a8456e3e09f999d'] = 'Sind Sie sich sicher, dass Sie Ihre Details löschen möchten?';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_21ee0d457c804ed84627ec8345f3c357'] = 'Einstellungen wurden erfolgreich gespeichert.';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c54f9f209ed8fb4683e723daa4955377'] = 'Hauptparameter';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3df24fbc81c688dc03a3fbc620b7915d'] = 'Die Anzahl der dargestellten Posts';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{smartblogpopularposts}prestashop>smartblogpopularposts_3f8ab412eb8ab369ea3f5c04db23febc'] = 'Populäre Artikel';
